package org.example;

import java.util.Scanner;

public class SistemaLogin {

    void telaLogin(){

        System.out.println("|--------------------------|");
        System.out.println("|      Tela de Login       |");
        System.out.println("|--------------------------|");

        System.out.println("|--------------------------|");
        System.out.println("|          Login:          |");
        System.out.println("|--------------------------|");

    }

    void telaLoginErro(){
        System.out.println("");
        System.out.println("Insira seu login novamente!");
        System.out.println("");
    }
    void telaSenha(){
        System.out.println("|--------------------------|");
        System.out.println("|          Senha:          |");
        System.out.println("|--------------------------|");
    }

    void telaAcessoLiberado(){
        System.out.println("|--------------------------|");
        System.out.println("|      Acesso liberado     |");
        System.out.println("|        Bem vindo!        |");
        System.out.println("|--------------------------|");
    }

    void telaAcessoNegado(){
        System.out.println("");
        System.out.println("|--------------------------|");
        System.out.println("|      Acesso Negado!      |");
        System.out.println("|--------------------------|");
        System.out.println("");
    }
}



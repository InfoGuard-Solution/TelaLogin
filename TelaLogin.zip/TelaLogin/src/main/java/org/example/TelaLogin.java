package org.example;

import java.util.Scanner;

public class TelaLogin {
    public static void main(String[] args) {

        SistemaLogin sistema = new SistemaLogin();

        for (int i = 0; i <= 3; i++) {
        Scanner leitor = new Scanner(System.in);
        String usuario = "admin";
        String senha = "123";

        sistema.telaLogin();
        String usuarioValidar = leitor.nextLine();

        if (usuarioValidar.equals(usuario)){
                sistema.telaSenha();
                String senhaValidar = leitor.nextLine();

                if (senhaValidar.equals(senha)) {
                    sistema.telaAcessoLiberado();
                    i=3;

                }else {
                    sistema.telaAcessoNegado();
                    i = 0;
                }
            }else {
                sistema.telaLoginErro();
                i = 0;
            }
        }
    }
}
